Place the TerpStore folder in the htdocs folder of your web server. The script in the processing folder will not work as
it is a php script that relies on a web server (e.g., XAMPP).